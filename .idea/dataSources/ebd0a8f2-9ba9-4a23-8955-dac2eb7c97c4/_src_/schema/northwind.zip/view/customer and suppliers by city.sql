CREATE VIEW `customer and suppliers by city` AS;
