CREATE VIEW `product sales for 1997` AS;
