CREATE VIEW `summary of sales by year` AS;
