CREATE VIEW `products by category` AS;
